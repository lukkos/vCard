<?php

/* LukkosVCardBundle:templates:listTemplate.html.twig */
class __TwigTemplate_c704305ef117d87e5a39b5e526a5d106d2236699719ec1ab49a32a01510bcfed extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "        <h1>Persons</h1>
        <p class=\"lead blue\">Click to show details.</p>
        
        ";
        // line 26
        echo "
            
            <div style=\"display:none\">{{flash | json}}</div>
        
        <div ng-show=\"flash.message\" class=\"alert alert-{{flash.status}}\" ><span class=\"glyphicon glyphicon-{{flash.icon}}\"></span>&nbsp; {{flash.message}}</div>
        
        <div class=\"list-group\">
            
            <a href=\"\" ng-click=\"open(vCardList.0.item.id)\" class=\"list-group-item\" ng-show=\"vCardList.0\">{{vCardList.0.item.name}} {{vCardList.0.item.surname}}</a>
            <a href=\"\" ng-click=\"open(vCardList.1.item.id)\" class=\"list-group-item\" ng-show=\"vCardList.1\">{{vCardList.1.item.name}} {{vCardList.1.item.surname}}</a>
            <a href=\"\" ng-click=\"open(vCardList.2.item.id)\" class=\"list-group-item\" ng-show=\"vCardList.2\">{{vCardList.2.item.name}} {{vCardList.2.item.surname}}</a>
            <a href=\"\" ng-click=\"open(vCardList.3.item.id)\" class=\"list-group-item\" ng-show=\"vCardList.3\">{{vCardList.3.item.name}} {{vCardList.3.item.surname}}</a>
            <a href=\"\" ng-click=\"open(vCardList.4.item.id)\" class=\"list-group-item\" ng-show=\"vCardList.4\">{{vCardList.4.item.name}} {{vCardList.4.item.surname}}</a>
            
        </div>
        
        <ul class=\"pagination pagination-sm\">
            <li><a href=\"\" ng-click=\"Pagination(vCardList.0.params,'prev')\">&laquo;</a></li>
            <li ng-repeat=\"n in range(1,vCardList.0.params.pageCount)\"  ng-class=\"{active: n==vCardList.0.params.current}\" ><a ng-click=\"Pagination(vCardList.0.params,n)\" href=\"\">{{n}} <span class=\"sr-only\">(current)</span></a></li>
            <li><a ng-click=\"Pagination(vCardList.0.params,'next')\" href=\"\">&raquo;</a></li>
        </ul>
        
        ";
    }

    public function getTemplateName()
    {
        return "LukkosVCardBundle:templates:listTemplate.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  24 => 26,  19 => 1,);
    }
}
