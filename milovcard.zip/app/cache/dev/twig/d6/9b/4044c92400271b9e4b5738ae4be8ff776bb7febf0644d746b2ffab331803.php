<?php

/* FOSUserBundle::layout.html.twig */
class __TwigTemplate_d69b4044c92400271b9e4b5738ae4be8ff776bb7febf0644d746b2ffab331803 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'fos_user_content' => array($this, 'block_fos_user_content'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
    </head>
    <body>
        <div>
            ";
        // line 8
        if ($this->env->getExtension('security')->isGranted("IS_AUTHENTICATED_REMEMBERED")) {
            // line 9
            echo "                ";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logged_in_as", array("%username%" => $this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "user"), "username")), "FOSUserBundle"), "html", null, true);
            echo " |
                <a href=\"";
            // line 10
            echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
            echo "\">
                    ";
            // line 11
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.logout", array(), "FOSUserBundle"), "html", null, true);
            echo "
                </a>
            ";
        } else {
            // line 14
            echo "                <a href=\"";
            echo $this->env->getExtension('routing')->getPath("fos_user_security_login");
            echo "\">";
            echo twig_escape_filter($this->env, $this->env->getExtension('translator')->trans("layout.login", array(), "FOSUserBundle"), "html", null, true);
            echo "</a>
            ";
        }
        // line 16
        echo "        </div>

        ";
        // line 18
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable($this->getAttribute($this->getAttribute($this->getAttribute((isset($context["app"]) ? $context["app"] : $this->getContext($context, "app")), "session"), "flashbag"), "all", array(), "method"));
        foreach ($context['_seq'] as $context["type"] => $context["messages"]) {
            // line 19
            echo "            ";
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["messages"]) ? $context["messages"] : $this->getContext($context, "messages")));
            foreach ($context['_seq'] as $context["_key"] => $context["message"]) {
                // line 20
                echo "                <div class=\"flash-";
                echo twig_escape_filter($this->env, (isset($context["type"]) ? $context["type"] : $this->getContext($context, "type")), "html", null, true);
                echo "\">
                    ";
                // line 21
                echo twig_escape_filter($this->env, (isset($context["message"]) ? $context["message"] : $this->getContext($context, "message")), "html", null, true);
                echo "
                </div>
            ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['message'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 24
            echo "        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['type'], $context['messages'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 25
        echo "
        <div>
            ";
        // line 27
        $this->displayBlock('fos_user_content', $context, $blocks);
        // line 29
        echo "        </div>
    </body>
</html>
";
    }

    // line 27
    public function block_fos_user_content($context, array $blocks = array())
    {
        // line 28
        echo "            ";
    }

    public function getTemplateName()
    {
        return "FOSUserBundle::layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  20 => 1,  23 => 1,  1080 => 340,  1074 => 338,  1068 => 336,  1066 => 335,  1064 => 334,  1060 => 333,  1051 => 332,  1048 => 331,  1036 => 326,  1030 => 324,  1024 => 322,  1022 => 321,  1020 => 320,  1016 => 319,  1010 => 318,  1007 => 317,  995 => 312,  989 => 310,  983 => 308,  981 => 307,  979 => 306,  975 => 305,  971 => 304,  967 => 303,  963 => 302,  957 => 301,  954 => 300,  946 => 296,  942 => 295,  939 => 294,  930 => 287,  928 => 286,  924 => 285,  921 => 284,  916 => 280,  908 => 278,  904 => 277,  902 => 276,  900 => 275,  897 => 274,  891 => 271,  888 => 270,  884 => 267,  881 => 265,  879 => 264,  876 => 263,  869 => 259,  867 => 258,  843 => 257,  840 => 255,  837 => 253,  835 => 252,  833 => 251,  830 => 250,  826 => 247,  824 => 246,  822 => 245,  819 => 244,  815 => 239,  812 => 238,  808 => 235,  806 => 234,  804 => 233,  801 => 232,  797 => 229,  795 => 228,  793 => 227,  791 => 226,  789 => 225,  786 => 224,  782 => 221,  779 => 216,  774 => 212,  754 => 208,  751 => 206,  748 => 205,  745 => 203,  742 => 202,  739 => 200,  737 => 199,  735 => 198,  732 => 197,  728 => 192,  726 => 191,  723 => 190,  719 => 187,  717 => 186,  714 => 185,  704 => 182,  701 => 180,  699 => 179,  696 => 178,  692 => 175,  690 => 174,  687 => 173,  683 => 170,  681 => 169,  678 => 168,  673 => 165,  671 => 164,  668 => 163,  663 => 160,  661 => 159,  658 => 158,  654 => 155,  652 => 154,  649 => 153,  645 => 150,  643 => 149,  640 => 148,  636 => 145,  633 => 144,  629 => 141,  627 => 140,  624 => 139,  620 => 136,  617 => 135,  614 => 133,  609 => 129,  599 => 128,  594 => 127,  592 => 126,  589 => 124,  587 => 123,  584 => 122,  579 => 118,  577 => 116,  576 => 115,  575 => 114,  574 => 113,  570 => 112,  567 => 110,  565 => 109,  562 => 108,  556 => 104,  554 => 103,  552 => 102,  550 => 101,  548 => 100,  544 => 99,  541 => 97,  539 => 96,  536 => 95,  522 => 92,  519 => 91,  505 => 88,  502 => 87,  477 => 82,  472 => 79,  470 => 78,  465 => 77,  463 => 76,  446 => 75,  443 => 74,  439 => 71,  429 => 66,  425 => 64,  421 => 62,  412 => 60,  410 => 59,  399 => 56,  397 => 55,  394 => 54,  389 => 51,  383 => 49,  377 => 47,  373 => 46,  370 => 45,  357 => 37,  349 => 34,  346 => 33,  342 => 30,  339 => 28,  334 => 26,  330 => 23,  328 => 22,  326 => 21,  323 => 19,  321 => 18,  317 => 17,  300 => 13,  295 => 11,  290 => 7,  287 => 5,  275 => 330,  270 => 316,  265 => 299,  263 => 294,  260 => 293,  257 => 291,  255 => 284,  250 => 274,  245 => 270,  242 => 269,  232 => 249,  222 => 238,  212 => 224,  207 => 216,  194 => 197,  186 => 190,  161 => 162,  146 => 147,  134 => 133,  76 => 17,  288 => 107,  282 => 3,  276 => 103,  274 => 102,  271 => 101,  259 => 100,  253 => 95,  249 => 93,  237 => 262,  234 => 88,  231 => 87,  226 => 85,  223 => 84,  211 => 76,  205 => 73,  195 => 71,  191 => 196,  184 => 68,  172 => 63,  181 => 185,  178 => 184,  170 => 77,  167 => 62,  165 => 75,  148 => 69,  137 => 65,  113 => 41,  104 => 63,  90 => 46,  58 => 18,  53 => 15,  188 => 194,  155 => 75,  152 => 74,  129 => 122,  126 => 121,  124 => 108,  97 => 52,  84 => 33,  81 => 24,  34 => 26,  114 => 91,  100 => 27,  65 => 35,  480 => 162,  474 => 80,  469 => 158,  461 => 155,  457 => 153,  453 => 151,  444 => 149,  440 => 148,  437 => 70,  435 => 69,  430 => 144,  427 => 65,  423 => 63,  413 => 134,  409 => 132,  407 => 131,  402 => 58,  398 => 129,  393 => 126,  387 => 122,  384 => 121,  381 => 48,  379 => 119,  374 => 116,  368 => 112,  365 => 41,  362 => 39,  360 => 38,  355 => 106,  341 => 105,  337 => 27,  322 => 101,  314 => 16,  312 => 98,  309 => 97,  305 => 95,  298 => 12,  294 => 109,  285 => 4,  283 => 88,  278 => 331,  268 => 300,  264 => 84,  258 => 81,  252 => 283,  247 => 273,  241 => 77,  229 => 86,  220 => 70,  214 => 231,  177 => 65,  169 => 168,  140 => 52,  132 => 65,  128 => 48,  107 => 64,  61 => 2,  273 => 317,  269 => 94,  254 => 92,  243 => 91,  240 => 263,  238 => 85,  235 => 250,  230 => 244,  227 => 243,  224 => 241,  221 => 77,  219 => 237,  217 => 232,  208 => 68,  204 => 215,  179 => 65,  159 => 158,  143 => 53,  135 => 51,  119 => 95,  102 => 36,  71 => 13,  67 => 20,  63 => 34,  59 => 36,  38 => 10,  94 => 45,  89 => 37,  85 => 25,  75 => 43,  68 => 36,  56 => 35,  87 => 25,  21 => 2,  26 => 6,  93 => 29,  88 => 6,  78 => 25,  46 => 14,  27 => 5,  44 => 15,  31 => 9,  28 => 3,  201 => 213,  196 => 211,  183 => 189,  171 => 173,  166 => 167,  163 => 78,  158 => 60,  156 => 157,  151 => 152,  142 => 59,  138 => 69,  136 => 138,  121 => 107,  117 => 44,  105 => 55,  91 => 27,  62 => 19,  49 => 19,  24 => 26,  25 => 3,  19 => 1,  79 => 18,  72 => 21,  69 => 11,  47 => 14,  40 => 11,  37 => 10,  22 => 17,  246 => 92,  157 => 56,  145 => 46,  139 => 139,  131 => 132,  123 => 58,  120 => 57,  115 => 43,  111 => 90,  108 => 56,  101 => 73,  98 => 34,  96 => 53,  83 => 46,  74 => 16,  66 => 9,  55 => 16,  52 => 17,  50 => 14,  43 => 12,  41 => 6,  35 => 5,  32 => 7,  29 => 8,  209 => 223,  203 => 78,  199 => 212,  193 => 73,  189 => 71,  187 => 69,  182 => 85,  176 => 178,  173 => 177,  168 => 80,  164 => 163,  162 => 74,  154 => 153,  149 => 148,  147 => 55,  144 => 144,  141 => 143,  133 => 50,  130 => 41,  125 => 59,  122 => 43,  116 => 94,  112 => 42,  109 => 87,  106 => 86,  103 => 28,  99 => 54,  95 => 33,  92 => 32,  86 => 36,  82 => 22,  80 => 28,  73 => 23,  64 => 3,  60 => 5,  57 => 11,  54 => 16,  51 => 33,  48 => 7,  45 => 13,  42 => 29,  39 => 9,  36 => 10,  33 => 8,  30 => 2,);
    }
}
