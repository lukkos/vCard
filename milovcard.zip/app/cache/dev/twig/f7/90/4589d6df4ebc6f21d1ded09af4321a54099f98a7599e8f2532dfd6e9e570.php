<?php

/* FOSUserBundle:Security:login.html.twig */
class __TwigTemplate_f7904589d6df4ebc6f21d1ded09af4321a54099f98a7599e8f2532dfd6e9e570 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        // line 4
        echo "    <div class=\"container\">
        <style type=\"text/css\">
          em { color:orange; }
        </style>
    <div style=\"width:300px; margin:auto; margin-top:100px;\">
    <p>
        Choose between two default users: <br /><em><b>milo</b> / milo</em> <small>(ROLE_USER)</small> <br /> <em><b>miloadmin</b> / miloadmin</em> <small>(ROLE_ADMIN)</small>
    </p>

    ";
        // line 13
        if ((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error"))) {
            // line 14
            echo "        <div class=\"error\" style=\"color:red;\">";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["error"]) ? $context["error"] : $this->getContext($context, "error")), "message"), "html", null, true);
            echo "</div>
    ";
        }
        // line 16
        echo "
    <form action=\"";
        // line 17
        echo $this->env->getExtension('routing')->getPath("fos_user_security_check");
        echo "\" method=\"post\" id=\"login\" class=\"form-signin\">
        <h2 class=\"form-signin-heading\">Sign in</h2>
        <input type=\"hidden\" name=\"_csrf_token\" value=\"";
        // line 19
        echo twig_escape_filter($this->env, (isset($context["csrf_token"]) ? $context["csrf_token"] : $this->getContext($context, "csrf_token")), "html", null, true);
        echo "\" />
        <input type=\"text\" class=\"form-control\" placeholder=\"Username\"  id=\"username\" name=\"_username\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, (isset($context["last_username"]) ? $context["last_username"] : $this->getContext($context, "last_username")), "html", null, true);
        echo "\" style=\"margin-top:10px;\"/>
        <input type=\"password\" class=\"form-control\" placeholder=\"Password\" id=\"password\" name=\"_password\" style=\"margin-top:10px;\"/>
        

        <button type=\"submit\" class=\"btn btn-lg btn-primary btn-block sf-button\" style=\"margin-top:10px;\">
            Login
        </button>
    </form>
    </div>
    </div>
";
    }

    public function getTemplateName()
    {
        return "FOSUserBundle:Security:login.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  62 => 20,  58 => 19,  53 => 17,  50 => 16,  44 => 14,  42 => 13,  31 => 4,  28 => 3,);
    }
}
