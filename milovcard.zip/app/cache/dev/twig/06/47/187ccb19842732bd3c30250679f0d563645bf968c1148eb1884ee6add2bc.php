<?php

/* LukkosVCardBundle:templates:index.html.twig */
class __TwigTemplate_0647187ccb19842732bd3c30250679f0d563645bf968c1148eb1884ee6add2bc extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("::base.html.twig");

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 2
    public function block_stylesheets($context, array $blocks = array())
    {
        // line 3
        echo "    <link href=\"../../../bundles/lukkosvcard/css/vcard.css\" rel=\"stylesheet\">
";
    }

    // line 5
    public function block_body($context, array $blocks = array())
    {
        // line 6
        echo "    
    <div class=\"navbar navbar-inverse navbar-fixed-top\" role=\"navigation\">
      <div class=\"container\">
        <div class=\"navbar-header\">
          <button type=\"button\" class=\"navbar-toggle collapsed\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
            <span class=\"sr-only\">Toggle navigation</span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
            <span class=\"icon-bar\"></span>
          </button>
            <a class=\"navbar-brand\" href=\"#\" style=\"white-space:nowrap\">vCard App<small style=\"display:block; color:#08C; font-size:10px; margin-top:-25px;\"><br />for Milosolutions</small></a> 
        </div>
        <div class=\"collapse navbar-collapse\">
          <ul class=\"nav navbar-nav\" ng-controller=\"topMenuCtrl\">
            <li class=\"dropdown\">
                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"\">vCards</a>
                <ul class=\"dropdown-menu\">
                    <li><a href=\"#\">Persons list</a></li>
                    <li><a ng-click=\"open()\" ng-show=\"";
        // line 24
        echo twig_escape_filter($this->env, $this->env->getExtension('security')->isGranted("ROLE_ADMIN"), "html", null, true);
        echo "\" href=\"\">Add vCard</a></li>
                </ul>
            </li>
            <li class=\"dropdown\"  ng-show=\"";
        // line 27
        echo twig_escape_filter($this->env, $this->env->getExtension('security')->isGranted("ROLE_ADMIN"), "html", null, true);
        echo "\">
                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"\">Companies</a>
                <ul class=\"dropdown-menu\">
                    <li><a href=\"#companies\">Companies list</a></li>
                    <li><a ng-click=\"openCompanyModal()\"  href=\"\">Add company</a></li>
                </ul>
            </li>
            <li class=\"dropdown\"  ng-show=\"";
        // line 34
        echo twig_escape_filter($this->env, $this->env->getExtension('security')->isGranted("ROLE_ADMIN"), "html", null, true);
        echo "\">
                <a class=\"dropdown-toggle\" data-toggle=\"dropdown\" href=\"\">App Users</a>
                <ul class=\"dropdown-menu\">
                    <li><a href=\"#users\">User list</a></li>
                    <li><a ng-click=\"openUserModal()\" href=\"\">Add user</a></li>
                </ul>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
        
          
        <ul class=\"nav navbar-nav navbar-right\" style=\"float:right; margin-top:-50px;\">
            <li><a href=\"";
        // line 46
        echo $this->env->getExtension('routing')->getPath("fos_user_security_logout");
        echo "\">Logout</a></li>
        </ul> 
      </div>
    </div>

    <div class=\"container\">

      <div class=\"starter-template\" ng-view>
        
      </div>

    </div><!-- /.container -->


    

";
    }

    // line 63
    public function block_javascripts($context, array $blocks = array())
    {
        // line 64
        echo "<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/angular.min.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/modules/underscore.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/modules/angular-animate.min.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/modules/angular-route.min.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/modules/dialogs.min.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/modules/restangular.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/modules/ui-bootstrap-tpls-0.10.0.min.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/loading-bar/src/loading-bar.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/app.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/factories.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/topMenu/controller.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/person/controller.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/person/factory.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/person/modalController.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/company/controller.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/company/factory.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/company/modalController.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/user/controller.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/user/factory.js\"></script>
<script type=\"text/javascript\" src=\"../../../bundles/lukkosvcard/js/user/modalController.js\"></script>
";
    }

    public function getTemplateName()
    {
        return "LukkosVCardBundle:templates:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  116 => 64,  113 => 63,  92 => 46,  77 => 34,  67 => 27,  61 => 24,  41 => 6,  38 => 5,  33 => 3,  30 => 2,);
    }
}
