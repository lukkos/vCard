<?php

/* LukkosVCardBundle:templates:personFormModal.html.twig */
class __TwigTemplate_52e7537c1634feebcbaa39e936e146959805c3c131128a7457cc308daaba7a03 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        if ($this->env->getExtension('security')->isGranted("ROLE_ADMIN")) {
            // line 2
            echo "        <div class=\"modal-header\">
            <h3 class=\"modal-title\">Person</h3>
        </div>
        <form novalidate name=\"";
            // line 5
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name"), "html", null, true);
            echo "_angular\" ng-submit=\"submit(lukkos_vcardbundle_person,'";
            echo $this->env->getExtension('routing')->getPath("new_vcard");
            echo "')\" ";
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'enctype');
            echo " role=\"form\">
        <div class=\"modal-body\">
        ";
            // line 9
            echo "
        <div ng-show=\"flash.message\" class=\"alert alert-{{flash.status}}\" ><span class=\"glyphicon glyphicon-{{flash.icon}}\"></span>&nbsp; {{flash.message}}</div>
        ";
            echo "
            ";
            // line 10
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget');
            echo "
            
            ";
            // line 16
            echo "
                
                <div style=\"display:none\">{{lukkos_vcardbundle_person|json}}</div>
                
            ";
            echo "
        </div>
        <div class=\"modal-footer\">
            <input type=\"submit\" class=\"btn btn-primary\" value=\"Save\" />
            <a href=\"\" ng-show=\"lukkos_vcardbundle_person.id\" class=\"btn btn-danger\" ng-click=\"remove(lukkos_vcardbundle_person)\">Delete</a>
            <a href=\"\" class=\"btn btn-warning\" ng-click=\"cancel()\">Cancel</a>
        </div>
        </form>
";
        } else {
            // line 25
            echo "    <div class=\"modal-header\">
            <h3 class=\"modal-title\">Person</h3>
    </div>
    <style type=\"text/css\">
        ul.milolist {
            list-style: none;
        }
        ul.milolist li{
            list-style: none;
            padding:10px;
        }
        ul.milolist li span{
            display: inline-block;
        }
        ul.milolist li span.label{
            color:#08C;   
            text-align:right;
            width:130px;
            padding-right:20px;
        }
    </style>
    <ul class=\"milolist\" ng-show=\"lukkos_vcardbundle_person.id\">
        ";
            // line 54
            echo "
        <li><span class=\"label\">Name:</span><span class=\"txt\">{{lukkos_vcardbundle_person.name}}</span></li>
        <li><span class=\"label\">Surname:</span><span class=\"txt\">{{lukkos_vcardbundle_person.surname}}</span></li>
        <li><span class=\"label\">Date of birth:</span><span class=\"txt\">{{lukkos_vcardbundle_person.date_of_birth}}</span></li>
        <li><span class=\"label\">Address:</span><span class=\"txt\">{{lukkos_vcardbundle_person.address}}</span></li>
        <li><span class=\"label\">Company:</span><span class=\"txt\">{{lukkos_vcardbundle_person.companyName}}</span></li>
        <li><span class=\"label\">Company address:</span><span class=\"txt\">{{lukkos_vcardbundle_person.companyAddress}}</span></li>
        ";
            echo "
    </ul>
    <div class=\"modal-footer\">
            <a href=\"\" class=\"btn btn-warning\" ng-click=\"cancel()\">Cancel</a>
    </div>        
";
        }
    }

    public function getTemplateName()
    {
        return "LukkosVCardBundle:templates:personFormModal.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  86 => 54,  62 => 25,  46 => 16,  41 => 10,  35 => 9,  26 => 5,  21 => 2,  19 => 1,);
    }
}
