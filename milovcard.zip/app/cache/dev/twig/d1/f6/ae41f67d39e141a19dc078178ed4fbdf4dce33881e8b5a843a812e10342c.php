<?php

/* LukkosVCardBundle:form:fields.html.twig */
class __TwigTemplate_d1f6ae41f67d39e141a19dc078178ed4fbdf4dce33881e8b5a843a812e10342c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = $this->env->loadTemplate("form_div_layout.html.twig");

        $this->blocks = array(
            'form_label' => array($this, 'block_form_label'),
            'form_row' => array($this, 'block_form_row'),
            'hidden_row' => array($this, 'block_hidden_row'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "form_div_layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 5
    public function block_form_label($context, array $blocks = array())
    {
        // line 6
        echo "    ";
        $this->displayParentBlock("form_label", $context, $blocks);
        echo "

    ";
        // line 8
        if ((isset($context["required"]) ? $context["required"] : $this->getContext($context, "required"))) {
            // line 9
            echo "        <span class=\"required\" title=\"Wymagane pole\">*</span>
    ";
        }
    }

    // line 13
    public function block_form_row($context, array $blocks = array())
    {
        // line 14
        echo "
    ";
        // line 15
        $context["formName"] = ($this->getAttribute($this, "getTopFormName", array(0 => (isset($context["form"]) ? $context["form"] : $this->getContext($context, "form"))), "method") . "_angular");
        // line 16
        echo "    ";
        $context["modelName"] = strtr($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "full_name"), array("[" => ".", "]" => ""));
        // line 17
        echo "    ";
        $context["formModelName"] = ((((isset($context["formName"]) ? $context["formName"] : $this->getContext($context, "formName")) . "['") . $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "full_name")) . "']");
        // line 18
        echo "    ";
        $context["ngClass"] = (((((("ng-class=\"{ 'has-error': " . (isset($context["formModelName"]) ? $context["formModelName"] : $this->getContext($context, "formModelName"))) . ".\$invalid && !") . (isset($context["formModelName"]) ? $context["formModelName"] : $this->getContext($context, "formModelName"))) . ".\$pristine || errors.") . $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name")) . "}\"");
        // line 19
        echo "    ";
        $context["attr"] = twig_array_merge((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), array("ng-model" => (isset($context["modelName"]) ? $context["modelName"] : $this->getContext($context, "modelName")), "ng-show" => 1));
        // line 20
        echo "    ";
        // line 21
        echo "    ";
        // line 22
        echo "    ";
        $context["formType"] = "basic";
        // line 23
        echo "

    ";
        // line 25
        if (((twig_in_filter("checkbox", $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "block_prefixes")) || twig_in_filter("radio", $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "block_prefixes"))) || ((twig_in_filter("choice", $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "block_prefixes")) && twig_in_filter("expanded", $this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"))) && ($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "expanded") == true)))) {
            // line 28
            echo "        ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), array("ng-model" => (isset($context["modelName"]) ? $context["modelName"] : $this->getContext($context, "modelName"))));
            // line 29
            echo "    ";
        } else {
            // line 30
            echo "        ";
            $context["classNames"] = "form-control";
            // line 31
            echo "        ";
            $context["class"] = ((twig_in_filter("class", twig_get_array_keys_filter((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr"))))) ? ((($this->getAttribute((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), "class") . " ") . (isset($context["classNames"]) ? $context["classNames"] : $this->getContext($context, "classNames")))) : ((isset($context["classNames"]) ? $context["classNames"] : $this->getContext($context, "classNames"))));
            // line 32
            echo "        ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), array("class" => (isset($context["class"]) ? $context["class"] : $this->getContext($context, "class")), "ng-model" => (isset($context["modelName"]) ? $context["modelName"] : $this->getContext($context, "modelName"))));
            // line 33
            echo "    ";
        }
        // line 34
        echo "

    ";
        // line 36
        if ((twig_in_filter("checkbox", $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "block_prefixes")) || twig_in_filter("radio", $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "block_prefixes")))) {
            // line 37
            echo "
        <div class=\"checkbox\">
            <label>
                ";
            // line 40
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget', array("attr" => (isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr"))));
            echo "
                ";
            // line 41
            echo twig_escape_filter($this->env, (($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "vars", array(), "any", false, true), "label", array(), "any", true, true)) ? (_twig_default_filter($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : null), "vars", array(), "any", false, true), "label"), $this->env->getExtension('form')->humanize($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name")))) : ($this->env->getExtension('form')->humanize($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name")))), "html", null, true);
            echo "
            </label>
        </div>

    ";
        } elseif (twig_in_filter("choice", $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "block_prefixes"))) {
            // line 46
            echo "
        <div class=\"form-group\" ";
            // line 47
            echo (isset($context["ngClass"]) ? $context["ngClass"] : $this->getContext($context, "ngClass"));
            echo ">
            ";
            // line 48
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'label');
            echo "

            ";
            // line 50
            if ((twig_in_filter("expanded", $this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars")) && ($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "expanded") == true))) {
                // line 51
                echo "                ";
                $context['_parent'] = (array) $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")));
                foreach ($context['_seq'] as $context["index"] => $context["choice"]) {
                    // line 52
                    echo "                    ";
                    if ((((isset($context["index"]) ? $context["index"] : $this->getContext($context, "index")) . "") != "placeholder")) {
                        // line 53
                        echo "                        <div class=\"radio\">
                            <label>
                                ";
                        // line 55
                        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")), 'widget', array("attr" => (isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr"))));
                        echo "
                                ";
                        // line 56
                        echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["choice"]) ? $context["choice"] : $this->getContext($context, "choice")), "vars"), "label"), "html", null, true);
                        echo "
                            </label>
                        </div>
                    ";
                    }
                    // line 60
                    echo "                ";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['index'], $context['choice'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 61
                echo "            ";
            } else {
                // line 62
                echo "                ";
                echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget', array("attr" => (isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr"))));
                echo "
                <span class=\"help-block\" ng-show=\"";
                // line 63
                echo twig_escape_filter($this->env, (isset($context["formModelName"]) ? $context["formModelName"] : $this->getContext($context, "formModelName")), "html", null, true);
                echo ".\$error.required && !";
                echo twig_escape_filter($this->env, (isset($context["formModelName"]) ? $context["formModelName"] : $this->getContext($context, "formModelName")), "html", null, true);
                echo ".\$pristine\">To pole jest wymagane. Wprowadź poprawną wartość</span>
            ";
            }
            // line 65
            echo "        </div>

    ";
        } else {
            // line 68
            echo "
        <div class=\"form-group\" ";
            // line 69
            echo (isset($context["ngClass"]) ? $context["ngClass"] : $this->getContext($context, "ngClass"));
            echo ">
            ";
            // line 70
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'label');
            echo "
            ";
            // line 71
            echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget', array("attr" => (isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr"))));
            echo "
            <span class=\"help-block\" ng-show=\"";
            // line 72
            echo twig_escape_filter($this->env, (isset($context["formModelName"]) ? $context["formModelName"] : $this->getContext($context, "formModelName")), "html", null, true);
            echo ".\$error.required && !";
            echo twig_escape_filter($this->env, (isset($context["formModelName"]) ? $context["formModelName"] : $this->getContext($context, "formModelName")), "html", null, true);
            echo ".\$pristine\">To pole jest wymagane. Wprowadź poprawną wartość</span>
            <span class=\"help-block\" ng-repeat=\"err in errors.";
            // line 73
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name"), "html", null, true);
            echo "\" ng-show=\"errors.";
            echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name"), "html", null, true);
            echo "\">
                ";
            // line 76
            echo "
                  {{err}}    
                ";
            echo "
            </span>
        </div>

    ";
        }
    }

    // line 84
    public function block_hidden_row($context, array $blocks = array())
    {
        // line 85
        echo "
    ";
        // line 86
        if (($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name") == "_token")) {
            // line 87
            echo "        ";
            $context["modelName"] = ($this->getAttribute($this, "getTopFormName", array(0 => (isset($context["form"]) ? $context["form"] : $this->getContext($context, "form"))), "method") . "._token");
            // line 88
            echo "        ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), array("ng-model" => (isset($context["modelName"]) ? $context["modelName"] : $this->getContext($context, "modelName")), "ng-init" => ((((isset($context["modelName"]) ? $context["modelName"] : $this->getContext($context, "modelName")) . " = \"") . $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "data")) . "\"")));
            // line 89
            echo "    ";
        } else {
            // line 90
            echo "        ";
            $context["modelName"] = strtr($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "full_name"), array("[" => ".", "]" => ""));
            // line 91
            echo "        ";
            $context["attr"] = twig_array_merge((isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr")), array("ng-model" => (isset($context["modelName"]) ? $context["modelName"] : $this->getContext($context, "modelName"))));
            // line 92
            echo "    ";
        }
        // line 93
        echo "

    ";
        // line 95
        echo $this->env->getExtension('form')->renderer->searchAndRenderBlock((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), 'widget', array("attr" => (isset($context["attr"]) ? $context["attr"] : $this->getContext($context, "attr"))));
        echo "
";
    }

    // line 100
    public function getgetTopFormName($_form = null)
    {
        $context = $this->env->mergeGlobals(array(
            "form" => $_form,
        ));

        $blocks = array();

        ob_start();
        try {
            ob_start();
            // line 101
            echo "
    ";
            // line 102
            if ((!(null === $this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent")))) {
                // line 103
                echo "        ";
                echo $this->getAttribute($this, "getTopFormName", array(0 => $this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "parent")), "method");
                echo "
    ";
            } elseif ((twig_in_filter("attr", twig_get_array_keys_filter($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"))) && twig_in_filter("name", twig_get_array_keys_filter($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "attr"))))) {
                // line 105
                echo "        ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "attr"), "name"), "html", null, true);
                echo "
    ";
            } else {
                // line 107
                echo "        ";
                echo twig_escape_filter($this->env, $this->getAttribute($this->getAttribute((isset($context["form"]) ? $context["form"] : $this->getContext($context, "form")), "vars"), "name"), "html", null, true);
                echo "
    ";
            }
            // line 109
            echo "
";
            echo trim(preg_replace('/>\s+</', '><', ob_get_clean()));
        } catch (Exception $e) {
            ob_end_clean();

            throw $e;
        }

        return ('' === $tmp = ob_get_clean()) ? '' : new Twig_Markup($tmp, $this->env->getCharset());
    }

    public function getTemplateName()
    {
        return "LukkosVCardBundle:form:fields.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  294 => 109,  288 => 107,  282 => 105,  276 => 103,  274 => 102,  271 => 101,  259 => 100,  253 => 95,  249 => 93,  246 => 92,  243 => 91,  240 => 90,  237 => 89,  234 => 88,  231 => 87,  229 => 86,  226 => 85,  223 => 84,  211 => 76,  205 => 73,  199 => 72,  195 => 71,  191 => 70,  187 => 69,  184 => 68,  179 => 65,  172 => 63,  167 => 62,  164 => 61,  158 => 60,  151 => 56,  147 => 55,  143 => 53,  140 => 52,  135 => 51,  133 => 50,  128 => 48,  124 => 47,  121 => 46,  113 => 41,  109 => 40,  104 => 37,  102 => 36,  98 => 34,  95 => 33,  92 => 32,  89 => 31,  86 => 30,  83 => 29,  80 => 28,  78 => 25,  74 => 23,  71 => 22,  69 => 21,  67 => 20,  64 => 19,  61 => 18,  58 => 17,  55 => 16,  53 => 15,  50 => 14,  47 => 13,  41 => 9,  30 => 5,  44 => 15,  39 => 8,  33 => 6,  24 => 4,  19 => 1,);
    }
}
